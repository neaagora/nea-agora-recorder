# Non-Goals

This project explicitly does NOT include:

- trust scoring
- cloud sync
- registries
- governance
